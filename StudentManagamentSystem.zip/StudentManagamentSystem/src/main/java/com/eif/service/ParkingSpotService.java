package com.eif.service;

import com.eif.data.ParkingSpot;
import com.eif.repo.ParkingSpotRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParkingSpotService {

    @Autowired
    private ParkingSpotRepo parkingSpotRepo;

    public ParkingSpot saveParkingSpot(ParkingSpot parkingSpot) {
        return parkingSpotRepo.save(parkingSpot);
    }

    public List<ParkingSpot> getParkingSpots() {
        return parkingSpotRepo.findAll();
    }

    public ParkingSpot getById(int id) {
        return parkingSpotRepo.findById(id).orElse(null);
    }

    public void delete(int id) {
        parkingSpotRepo.deleteById(id);
    }
}
