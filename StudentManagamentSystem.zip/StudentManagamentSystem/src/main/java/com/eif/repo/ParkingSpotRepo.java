package com.eif.repo;

import com.eif.data.ParkingSpot;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParkingSpotRepo extends JpaRepository<ParkingSpot, Integer> {
}
