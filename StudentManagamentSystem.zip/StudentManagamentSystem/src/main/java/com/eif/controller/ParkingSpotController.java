package com.eif.controller;

import com.eif.data.ParkingSpot;
import com.eif.service.ParkingSpotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController

public class ParkingSpotController {

    @Autowired
    private ParkingSpotService parkingSpotService;

    @GetMapping("/spots")
    public List<ParkingSpot> getAllParkingSpots() {
        return parkingSpotService.getParkingSpots();
    }

    @PostMapping("/addSpot")
    public void addParkingSpot(@RequestBody ParkingSpot parkingSpot) {
        parkingSpotService.saveParkingSpot(parkingSpot);
    }

    @GetMapping("/spot/{id}")
    public ParkingSpot getParkingSpotById(@PathVariable int id) {
        return parkingSpotService.getById(id);
    }

    @PutMapping("/updateSpot")
    public void updateParkingSpot(@RequestBody ParkingSpot parkingSpot) {
        parkingSpotService.saveParkingSpot(parkingSpot);
    }

    @DeleteMapping("/spots/{spotId}")
    public void deleteParkingSpot(@PathVariable int spotId) {
        parkingSpotService.delete(spotId);
    }
}
